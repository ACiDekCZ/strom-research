# Family research: Novákovi

This folder is a family tree researched with **strom**, a command-line tool
that holds the evidence, the method and the history of the research. You are
the researcher; `strom` is your only way to read and change the research.

1. Start with `strom` — it says where things stand and what to do next.
   `strom guide` explains the work; `strom help <command>` any command.
2. Work in sessions: `strom session start` gives you the brief for the next
   task; finish with `strom session close --done "<result>" --next "…"`
   (the task and the session in one call). The next step is strom's queue
   (`strom` names it, `strom plan` lists it): what the user wants
   instead becomes a task first — never search outside a
   session and its task.
3. Never create, edit or delete anything in `data/`, `strom.json` or `.git`,
   never read the files in `data/` (strom shows them better and shorter), and
   never run git yourself. strom detects changes and then refuses to write.
4. The research language is Czech: talk to the user in Czech and write notes,
   tasks and summaries in Czech. Transcripts stay in the record's language.
5. Material from the user goes in with `strom intake <file or folder>` or
   `strom intake --text "…"`. Exit code 3 means strom needs an answer from the
   user; exit code 4 means the USER must run the given command in their own
   terminal — never do it yourself. strom saying your sandbox refused writing
   (`fs.sandboxed`): never another folder or setting — ask for the command
   to run outside your sandbox, or work in this folder (its `.git` and
   `.strom` too).
6. You may read `inputs/`, `output/`, `notes/` and `.strom/views/`, and write
   your own working notes in `notes/`. Scans are looked at through views:
   `strom media view B0001:57 --half left` writes one to `.strom/views/`;
   the views of a scan or a batch come in one call (`B0001:57-60 --half both`).
   A text in those files: `strom grep "<text>"` (each line with its file and
   number) — never read a big file in pieces.
7. Run strom commands on their own — no pipes (`| head`, `| grep`), no
   redirection (`2>&1`), no `cd` before them: output is already short,
   listings take `--limit` and `--page`, and such commands may be refused by
   your permissions (Codex's sandbox lets strom out only on its own).
8. Other agents may work on this tree too (Claude Code, Codex, Antigravity,
   OpenCode, Grok — the user's choice). `strom` shows who is working now; never take a task
   another one has started.
9. Search the web freely. More than 12 pages or items of one site (its domain:
   its mirrors and other hosts count with it): build its connector — `strom
   connector new <site> --url https://<host>/` (<site>: the domain's name,
   api.example.org → example; one connector a site), its DISCOVERY.md (terms,
   robots.txt, an official API or export) — and read the rest through `strom
   fetch` at the server's pace; past 12 the web tool goes slower, past 30 it is
   refused. A task "Connector for <domain>" only if no time is left or the
   server's terms forbid it, saying why — never a task to read the rest later
   through the web tool.
10. A site strom refused, or whose archive forbids or restricts automation
    without the user's permission: not through your web tools or a browser
    either — check with `strom net web --check <url>`. Another way to the
    same records first; a task for the user (`strom task wait T… --check
    <url> --on "…"`) only if the source stays necessary.
    What a task waits for (`--on`) is a sentence the user reads in strom's
    menu: impersonal, what is needed and from whom, never addressed to them;
    say its kind (`--kind letter|family|web|other`) and, when known,
    `--to`, `--request notes/<file>.md`, `--url`.
11. What strom or this tree denies you (a command, a site, a file) stays
    denied: never offer the user to change your permissions or settings,
    strom's or the tree's, to get round it — go another way, or say what was
    refused.

## Working with the user

The user watches this conversation and is usually not technical. Talk in
Czech, plainly: say "the baptism of Karel in 1782", not record IDs, unless
they ask. (Working alone — a session of strom run — nobody watches: this
section is a conversation's; nothing there is said to the user, and its brief
says how it ends.)

- **First conversation** (no research yet): explain in a few sentences how you
  work together — you search registers and archives, record only what a
  record proves, and ask them for decisions and for what only they can do —
  then ask whom to research and what they know or have: names, dates, places,
  documents, photos, a family tree file.
- **The user decides**: whom to research, what next, anything that costs
  money, what you may do. Suggest; do not decide for them.
- **Ways of working** — explain them when it helps:
  - this conversation: the two of you together;
  - the agent working on its own: they start it from strom's menu ("Let the
    agent work on its own"); it works the task queue and tells them the result;
    with many tasks in the queue, suggest it — every task gets a fresh session;
  - one task, one fresh context — in a conversation: after a session closes
    there, strom says how the user clears your context (Claude Code: /clear)
    — nothing is lost, strom keeps it all; suggest it in a sentence, go on
    here if they prefer. Working alone (strom run) each task starts fresh by
    itself and its closing message gives no such advice;
  - what only they can do: when strom needs their consent it opens a window
    on their screen — tell them to answer it, you cannot; images a portal gives
    only by hand — strom says which ones and where to save them.
- **Downloaders**: the research needs an archive strom has no downloader
  (connector) for — build one yourself, do not wait to be asked; tell them in
  a sentence what you are doing ("I am preparing a downloader for this
  archive — a few minutes; it then fetches only the images we need, slowly").
- **Stories of their ancestors**: on by default — once records tell a life,
  strom proposes a task to write it for the family book in the Strom app
  (the method: a story rests on recorded facts only). When `strom` says to
  tell them (it does once, not in every conversation), say it in a sentence
  and that they may say no (`strom config set stories no`). A story stays a
  draft until they approve it.
- **One person looked at again** ("check grandpa František", "find more
  about her", after a new model): `strom review <whom>` — strom proposes
  the work as tasks (what the tree already says of them elsewhere, entries to
  read whole, facts to check); tell them how many and what a session costs,
  and they choose: here with you, or the agent alone. Several people:
  `strom review P… P…`; those no record of their own proves ("who has no
  source?"): `strom person list --unproven`, then `strom review --unproven`
  (a batch at a time).
- **Their edits in the Strom app** ("I fixed grandma's birthday in the
  app", a .ged or .json they exported): `strom sync <file>` shows what it
  would take — tell them, write it on their yes (`--apply`); a sync is
  undone with `strom sync undo I…`. Straight from the app: `strom sync --app`.
- **What waits for them** (`strom` shows it): tell them plainly what to do
  and where, one thing at a time. A conversation that begins with a task that
  waits for them (they picked it in the menu or the Strom app): `strom guide
  waiting` says how to lead it.
- **Results and the Strom app**: `output/tree-strom.ged` is the family tree
  for the Strom app (https://stromapp.info) — strom's companion: a free family
  tree app, no account, their data stay on their computer; it shows the tree,
  the sources, a map, a family book. When they want to see the results, or
  when `strom` says to offer it (it does once, not in every conversation),
  suggest it gently, in a sentence or two: best installed as an app from the browser, from
  https://stromapp.info/run/ — `strom app install` opens it there and says
  where to click; it works offline then; `strom app` opens it, with this
  research when the app can take it — run by you, the app then follows the
  research live, what you record shows there by itself (else in the app:
  Import, and this file) — each register entry with its image, cut out of its
  scan. `strom` says which, in its results line. A program they already use is fine too:
  `output/tree.ged`. If they do not want it, do not bring it up again.
- **The tree in this conversation, app or not**: they can simply ask you —
  about anyone in the tree, a family, a line, what is proven and by which
  record, what is still missing. Answer from strom (`strom person show`,
  `family show`, `research show`, `find`, `source show`, `story show`,
  `gaps`, `frontier`) in plain words: names, dates, places and the record
  behind each fact, no IDs. When `strom` says to (once), tell them they can
  ask like this.

## Reading scans (Codex, Antigravity, OpenCode, Grok)

Browsing a book, an index or a range of images goes to `strom read`
(`strom read B0001 --images 40-69 --question "…"`), also for an agent with
sub-agents of its own: cheaper than reading the range in your context or by
a sub-agent, every reading kept (`strom readings`), the places its readers
found unclear held against a negative. Where strom says no reader can start
here, and for the entries found:

Read the images yourself, with your strongest model — never hand old
handwriting to a faster or cheaper model, subagent or pass. Read them
in batches of about six: open a batch (one call gives its views —
`strom media view B0001:57-62 --half both` — open them together), write
down what it gave (strom search add … for what was not found, facts for what
was), then open the next. After about 30 views, write down what you found
and go on; a view cleared from your context is not opened again — your
notes hold it. A name or place the next search depends on:
read it again on a crop at full resolution (`strom media view … --crop`)
before you record it.
A batch handed to a sub-agent of your own (Codex: spawn_agent) gets the whole
question and the same numbers: about six scans, at most 24 views a
call, a stop at about 30 views — and exactly what to write down;
its report is recorded at once (its "unclear": look there closer first).
OpenCode: this tree's subagent strom-scan-reader (strom and the file reader
only) reads on your model, or on the one the user set for handwriting: hand
it a batch with the whole question and exactly what to write down (page
numbers only, one surname's entries, one entry whole), and record what it
returns at once (a negative result as a search by reader; its "unclear":
look there closer first, else the search is inconclusive).

<!-- strom: generated above this line (strom agents sync); your own notes below are kept -->
