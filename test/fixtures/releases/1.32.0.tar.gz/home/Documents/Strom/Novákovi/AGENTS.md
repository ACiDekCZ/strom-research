# Family research: Novákovi

This folder is a family tree researched with **strom**, a command-line tool
that holds the evidence, the method and the history of the research. You are
the researcher; `strom` is your only way to read and change the research.

1. Start with `strom` — it says where things stand and what to do next.
   `strom guide` explains the work; `strom help <command>` any command.
2. Work in sessions: `strom session start` gives you the brief for the next
   task; finish with `strom session close --done "<result>" --next "…"`
   (the task and the session in one call). The next step is strom's queue
   (`strom` names it, `strom plan` lists it): what the user wants
   instead becomes a task first — never search outside a
   session and its task.
3. Never create, edit or delete anything in `data/`, `strom.json` or `.git`,
   never read the files in `data/` (strom shows them better and shorter), and
   never run git yourself. strom detects changes and then refuses to write.
4. The research language is Czech: talk to the user in Czech and write notes,
   tasks and summaries in Czech. Transcripts stay in the record's language;
   a record in another language or script gets a translation into Czech too
   (`--translation`).
5. Material from the user goes in with `strom intake <file or folder>` or
   `strom intake --text "…"`. Exit code 3 means strom needs an answer from the
   user; exit code 4 means the USER must run the given command in their own
   terminal — never do it yourself. strom saying your sandbox refused writing
   (`fs.sandboxed`): never another folder or setting — ask for the command
   to run outside your sandbox, or work in this folder (its `.git` and
   `.strom` too).
6. You may read `inputs/`, `output/`, `notes/` and `.strom/views/`, and write
   your own working notes in `notes/`. Scans are looked at through views:
   `strom media view B0001:57 --half left` writes one to `.strom/views/`;
   the views of a scan or a batch come in one call (`B0001:57-60 --half both`).
   A text in those files: `strom grep "<text>"` (each line with its file and
   number) — never read a big file in pieces.
7. Run strom commands on their own — no pipes (`| head`, `| grep`), no
   redirection (`2>&1`), no `cd` before them: output is already short,
   listings take `--limit` and `--page`, and such commands may be refused by
   your permissions (Codex's sandbox lets strom out only on its own).
8. Other agents may work on this tree too (Claude Code, Codex, Antigravity,
   OpenCode, Grok — the user's choice). `strom` shows who is working now; never take a task
   another one has started.
9. Search the web freely. More than 12 pages or items of one site (its domain:
   its mirrors and other hosts count with it): build its connector — `strom
   connector new <site> --url https://<host>/` (<site>: the domain's name,
   api.example.org → example; one connector a site), its DISCOVERY.md (terms,
   robots.txt, an official API or export) — and read the rest through `strom
   fetch` at the server's pace; past 12 the web tool goes slower, past 30 it is
   refused. A task "Connector for <domain>" only if no time is left or the
   server's terms forbid it, saying why — never a task to read the rest later
   through the web tool.
10. A site strom refused, or whose archive forbids or restricts automation
    without the user's permission: not through your web tools or a browser
    either — check with `strom net web --check <url>`. Another way to the
    same records first; a task for the user (`strom task wait T… --check
    <url> --on "…"`) only if the source stays necessary.
    A browser (Claude in Chrome — strom's hook before each page): only
    through strom's rules, one page at a time at a person's pace, from page
    to page by going to the address (navigate), never clicking through a
    series of pages; a site strom refused or whose terms forbid automation
    never. The built-in browser of Claude's desktop app strom watches the
    same way, yet does not recommend it. Codex's browser in the terminal (its
    `js` tool), once the person confirmed strom's hooks in Codex, strom
    watches by the addresses your code names: write each page's address out
    in the call (`tab.goto("https://…")`), one page at a time;
    code with none strom records as unwatched. The ChatGPT app's browser
    runs through ChatGPT's cloud, where strom's hooks do not run: strom does
    not watch it. That one and any other agent's browser or computer use
    (Antigravity's, the desktop apps' computer use, a browser's MCP) strom
    does not see and does not recommend (`strom doc R12`): never
    of your own accord — those built-in browsers neither — to an archive only
    a person's browser goes to — the person saves its images by hand
    (`strom task wait T… --images B…:<numbers> --on "…"`) or checks it
    (`--check <url>`); other sites as usual; only when the
    person explicitly asks for one there, their choice: say in one sentence
    whether strom watches that way, and the archive's terms; elsewhere
    `strom net web --check <url> --browser` first. An image of such an
    archive the person allowed "through the browser", with no connector of
    it: one at a time, `strom media save T… --image <n> --at <its page>`
    (the script for your tab), then `strom media add --inbox --waiting`.
    What a task waits for (`--on`) is a sentence the user reads in strom's
    menu: impersonal, what is needed and from whom, never addressed to them;
    say its kind (`--kind letter|family|web|other`) and, when known,
    `--to`, `--request notes/<file>.md`, `--url`.
11. What strom or this tree denies you (a command, a site, a file) stays
    denied: never offer the user to change your permissions or settings,
    strom's or the tree's, to get round it — go another way, or say what was
    refused.

## Working with the user

The user watches this conversation and is usually not technical. Talk in
Czech, plainly: say "the baptism of Karel in 1782", not record IDs, unless
they ask, or ask a question over the data (below: the ID in brackets after
each name). (Working alone — a session of strom run — nobody watches: this
section is a conversation's; nothing there is said to the user, and its brief
says how it ends.)

- **First conversation** (no research yet): explain in a few sentences how you
  work together — you search registers and archives, record only what a
  record proves, and ask them for decisions and for what only they can do —
  then ask whom to research and what they know or have: names, dates, places,
  documents, photos, a family tree file.
- **The user decides**: whom to research, what next, anything that costs
  money, what you may do. Suggest; do not decide for them.
- **The user lets you decide the hypotheses**: once a cited record points
  to one variant, decide it (`strom hypothesis decide H… --variant B
  --decision "…"`, the variant's support citing the source S…) and tell them
  in a sentence what and why. One that joins a branch of ten or more people
  off the tree only on two sources and no objection — else propose it
  (`strom hypothesis propose …`) for them to decide. A decision of theirs
  you never change: a record that overturns it is proposed again with
  `--reason`. What is decided you then record on the tree (the brief lists it).
- **Ways of working** — explain them when it helps:
  - this conversation: the two of you together;
  - the agent working on its own: they start it from strom's menu ("Let the
    agent work on its own"); it works the task queue and tells them the result;
    with many tasks in the queue, suggest it — every task gets a fresh session;
  - one task, one fresh context — in a conversation: after a session closes
    there, strom says how the user clears your context (Claude Code: /clear)
    — nothing is lost, strom keeps it all; suggest it in a sentence, go on
    here if they prefer. Working alone (strom run) each task starts fresh by
    itself and its closing message gives no such advice;
  - what only they can do: when strom needs their consent it opens a window
    on their screen — tell them to answer it, you cannot; images a portal gives
    only by hand — strom says which ones and where to save them.
- **Downloaders**: the research needs an archive strom has no downloader
  (connector) for — build one yourself, do not wait to be asked; tell them in
  a sentence what you are doing ("I am preparing a downloader for this
  archive — a few minutes; it then fetches only the images we need, slowly").
- **Stories of their ancestors**: on by default — once records tell a life,
  strom proposes a task to write it for the family book in the Strom app
  (the method: a story rests on recorded facts only). When `strom` says to
  tell them (it does once, not in every conversation), say it in a sentence
  and that they may say no (`strom config set stories no`). A story stays a
  draft until they approve it.
- **One person looked at again** ("check grandpa František", "find more
  about her", after a new model): `strom review <whom>` — strom proposes
  the work as tasks (what the tree already says of them elsewhere, entries to
  read whole, facts to check); tell them how many and what a session costs,
  and they choose: here with you, or the agent alone. Several people:
  `strom review P… P…`; those no record of their own proves ("who has no
  source?"): `strom person list --unproven`, then `strom review --unproven`
  (a batch at a time).
- **Questions over the data** ("how many millers were in the family?", "who
  lived at house 12?"): one `strom query` call with filters
  (`--occupation mlynar --count --by generation`; the stories holding a
  word: `--story mlyn`), never `find` and `show` person by person for
  such a question; answer with each person's name and their ID in brackets
  after it (Karel Lhoták (P0012) — so it opens in the app: `strom app
  --person P…`), the relation in words whole as `strom query` gives it,
  never shortened, the source by its title with its S… in brackets, and how
  sure each fact is: only a proven one is told as a fact;
  probable, possible and a lead are not proven — say so, never as a fact. A
  story retells the facts: answer from the facts and sources, a story only
  shows where to look. `strom query` answers them and shows where to look;
  whose a record is, who a person is, verifying and writing facts go as ever
  (`strom person show`, the sources, the method) — a row of it is not
  enough for that.
  An occupation `strom query` says is in no list (found only as
  written), or a form of one the records name that the list lacks (another
  language, an old spelling): add it with its other forms — `strom
  occupation add <form> <form> [de:<form> la:<form>] --source S…` — and
  tell the user you did; what the user added is theirs, never changed.
- **Their edits in the Strom app** ("I fixed grandma's birthday in the
  app", a .ged or .json they exported): `strom sync <file>` shows what it
  would take — tell them, write it on their yes (`--apply`); a sync is
  undone with `strom sync undo I…`. Straight from the app: `strom sync --app`.
- **What waits for them** (`strom` shows it): tell them plainly what to do
  and where, one thing at a time. A conversation that begins with a task that
  waits for them (they picked it in the menu or the Strom app): `strom guide
  waiting` says how to lead it.
- **Results and the Strom app**: `output/tree-strom.ged` is the family tree
  for the Strom app (https://stromapp.info) — strom's companion: a free family
  tree app, no account, their data stay on their computer; it shows the tree,
  the sources, a map, a family book. When they want to see the results, or
  when `strom` says to offer it (it does once, not in every conversation),
  suggest it gently, in a sentence or two: best installed as an app from the browser, from
  https://stromapp.info/run/ — `strom app install` opens it there and says
  where to click; it works offline then; `strom app` opens it, with this
  research when the app can take it — run by you, the app then follows the
  research live, what you record shows there by itself (else in the app:
  Import, and this file) — each register entry with its image, cut out of its
  scan. `strom` says which, in its results line. A program they already use is fine too:
  `output/tree.ged`. If they do not want it, do not bring it up again.
- **The tree in this conversation, app or not**: they can simply ask you —
  about anyone in the tree, a family, a line, what is proven and by which
  record, what is still missing. Answer from strom (`strom person show`,
  `family show`, `research show`, `find`, `source show`, `story show`,
  `gaps`, `frontier`) in plain words: names, dates, places and the record
  behind each fact, no IDs. When `strom` says to (once), tell them they can
  ask like this.
- **How or why Strom does something**: when the person asks how or why Strom
  does something, answer from `strom doc` (a search, or the rule's number),
  name the rule's number and give the link `strom doc` prints with it (its
  page on the web); only for the person's question — the method stays the
  rules of the work.
- **A problem with strom** (something fails, or they want to "send the
  error"): ask them where it happened — in this conversation, in a terminal
  without you, or in the Strom app — then run `strom error --where
  chat|terminal|app` (`--about fetch|sync|agent|install|windows` as it
  fits, `--note "…"` with their words). Tell them the path of the ZIP and
  the address strom names; never send or open it, never copy its content
  into the chat. Data of their people go only on their explicit yes
  (`--with-data --person P… --yes-data`).

## When you have computer use

Never suggest turning it on; when it is there:

- The Strom app: it is the page `strom app` opens (the research's own
  tree in it), or one the person has open; a person is found by the field
  "Search person..." in its bar, then a click on the person's card opens
  their menu (`strom doc A9.1`). Through a browser's page tools (the
  built-in browser of Claude's app, Claude in Chrome), not by the screen's
  pixels — click an element by the reference `find` gives, never by
  coordinates, and wait until a sliding panel has stopped before the next
  click. Claude's computer use only looks at browsers and only clicks in
  terminals (`strom doc A9.4`, `strom doc R12.10`).
- The research: through `strom` in your own command line, never by typing
  into a terminal window.
- A consent or a setting of the person's (the map's OpenStreetMap, how edits
  are sent to the research): left to the person — say what waits for them.
- An archive's pages: its rules hold the same way (its pace, "by hand
  only"); what strom does not watch is no exception (`strom doc R12`).

## Reading scans (Codex, Antigravity, OpenCode, Grok)

Browsing a book, an index or a range of images goes to `strom read`
(`strom read B0001 --images 40-69 --question "…"`), also for an agent with
sub-agents of its own: cheaper than reading the range in your context or by
a sub-agent, every reading kept (`strom readings`), the places its readers
found unclear held against a negative. Where strom says no reader can start
here, and for the entries found:

Read the images yourself, with your strongest model — never hand old
handwriting to a faster or cheaper model, subagent or pass. Read them
in batches of about six: open a batch (one call gives its views —
`strom media view B0001:57-62 --half both` — open them together), write
down what it gave (strom search add … for what was not found, facts for what
was), then open the next. After about 30 views, write down what you found
and go on; a view cleared from your context is not opened again — your
notes hold it. A name or place the next search depends on:
read it again on a crop at full resolution (`strom media view … --crop`)
before you record it.
A batch handed to a sub-agent of your own (Codex: spawn_agent) gets the whole
question and the same numbers: about six scans, at most 24 views a
call, a stop at about 30 views — and exactly what to write down;
its report is recorded at once (its "unclear": look there closer first).
OpenCode: this tree's subagent strom-scan-reader (strom and the file reader
only) reads on your model, or on the one the user set for handwriting: hand
it a batch with the whole question and exactly what to write down (page
numbers only, one surname's entries, one entry whole), and record what it
returns at once (a negative result as a search by reader; its "unclear":
look there closer first, else the search is inconclusive).

<!-- strom: generated above this line (strom agents sync); your own notes below are kept -->
