# Grok Build in this family tree

CLAUDE.md in this folder is written for Claude Code: its way of delegating (the
Agent tool, the models opus, sonnet and haiku) is not yours. Follow AGENTS.md,
and read scans yourself as it says under "Reading scans".
