@AGENTS.md

Claude Code: use Bash for `strom` commands only; read images and documents
with the Read tool. You can choose a model for a subagent: delegate reading as
below, not the way "Reading scans" in AGENTS.md says for other agents.

## Delegating work (Claude Code)

Use the Agent tool for subagents; each has a clean context and only its answer
comes back to you. Choose the model by the kind of work:

| work | model |
|---|---|
| handwriting: registers, indexes, land books, any scan read closely | `opus` — never cheaper |
| print and type: documents of the 20th century, catalogues, web pages, big text files | `sonnet` |
| mechanical: downloads, renaming, counting, a plain grep | `haiku` |
| judgement: identity, conflicts, which task next, writing to strom | nobody — you |

- Browsing a book, an index or a range of images ("is our surname on this page?")
  is delegated; so is anything self-contained that returns little.
- About ten images per delegate, never more than twelve: an image stays in the
  context of whoever opened it and is paid for again on every turn.
- Every delegate gets the full question (what counts as a find, which years,
  which names) and returns for each image: image and page, find or nothing,
  what was illegible, the hand, and certainty per name — written as it goes.
- Delegates never write to the research. You record their findings through
  strom; a negative result of a delegate is recorded as a search "by reader".
- Only entries that will get a citation need your own eyes.
- Send independent batches in ONE message so they run in parallel.
- Do not read a subagent's transcript or output file — its images would come
  into your context. Use only its final answer.

<!-- strom: generated above this line (strom agents sync); your own notes below are kept -->
