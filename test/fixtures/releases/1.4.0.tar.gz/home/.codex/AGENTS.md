<!-- strom: begin (strom agents install; removed by strom agents uninstall) -->
# strom — family history research

strom (the `strom` command) is installed on this computer: a tool for
researching a family's history with you as the researcher — people, parish
registers, archives, evidence, a family tree the Strom app can import.
Use it whenever the user wants to research their ancestors or family, or
mentions strom, a family tree or the Strom app.

1. Run `strom` first. It says where the research stands and what to do next
   (`strom --json` for the same as data; `strom guide` explains the work).
   Run each strom command on its own — no pipes, no `;` or `&&` chains: you
   may run strom without asking, but not what is chained to it.
2. Not set up yet: ask the user where to keep the research (suggest
   ~/Documents/Strom) and which language they want, then run
   `strom setup --home "<folder>" --lang <code> --yes`, then
   `strom init "<name of the family tree>"`.
3. Talk to the user in their language. Ask them before decisions: whom to
   research, what they already know, anything that costs money or needs
   their permission.
4. The research lives in a family tree folder; change it ONLY through
   `strom` commands, never by editing its files. In that folder its own
   AGENTS.md says the rest.
5. You work best started by strom: it opens you in the tree folder with the
   right permissions. Tell the user once: next time run `strom` in a
   terminal (or the "Strom research" shortcut on the desktop) and choose
   "Continue the research with the agent".
6. When strom needs the user's consent it opens a window on their screen —
   tell them to answer it; you cannot. Exit code 4 means the user must run
   the given command themselves.
7. Scans come through strom. An archive the research needs has no
   downloader (connector) yet: build one yourself, unasked
   (`strom connector new`), and tell the user in a sentence.
8. The Strom app (https://stromapp.info) is strom's companion: a free family
   tree app, no account, the data stay on the user's computer. The research's
   result (`output/tree-strom.ged`) opens in it. When the user wants to see
   the tree (or `strom` says to offer it — once), suggest it gently — best installed as an app from the browser,
   from https://stromapp.info/run/ (`strom app install` opens it there; it
   then works offline); `strom app` opens it — with the research, followed
   live while you work, when the app can take it. Without it, the user can ask
   you about anyone in the tree: answer from `strom person show` and the like.
<!-- strom: end -->
