@AGENTS.md

Claude Code: use Bash for `strom` commands only; read images and documents
with the Read tool. You can choose a model for a subagent: delegate reading as
below, not the way "Reading scans" in AGENTS.md says for other agents.

## Delegating work (Claude Code)

Use the Agent tool for subagents; each has a clean context and only its answer
comes back to you. Choose the model by the kind of work:

| work | model |
|---|---|
| handwriting: registers, indexes, land books, any scan read closely | `strom-scan-reader`, on your own model — never cheaper |
| print and type: documents of the 20th century, catalogues, web pages, big text files (the lines `strom grep` found) | `sonnet` |
| mechanical: downloads, renaming, counting | `haiku` |
| a text in inputs/ or notes/ | nobody — `strom grep`, one call |
| judgement: identity, conflicts, which task next, writing to strom | nobody — you |

Scans are read by this tree's subagent type `strom-scan-reader` (strom and the
file reader only, so it starts small). Call it without `model`: strom set its
model (the user's choice for handwriting), and a call naming another is refused.

- Browsing a book, an index or a range of images ("is our surname on this page?")
  goes to `strom read` (by halves: `--half both`); a delegate reads only crops
  of the entries found. Anything self-contained that returns little is delegated.
- A delegate other than strom-scan-reader (text, print, a search) gets no brief:
  begin its prompt with this, word for word — "A family research kept with strom: you read and report, you never write to it. Run each `strom …` command on its own — no pipes, `;`, `&&`, `$(…)`, variables, awk or any other program: they are refused. Read opens inputs/, notes/, output/ and .strom/views/ only, never data/. A text in those files: `strom grep "<text>" [--in inputs|notes|I…] [--context 2]` — never Read a big file in pieces."
- About six scans (images B…:n) per delegate, four views each (halves and
  crops); tell it to write down what each call gave before the next, to stop
  at about 30 views and return what it has, and never to open again a view
  cleared from its context (its notes hold it). It asks for the
  views of a scan (or of a few) in one call —
  `strom media view B0001:57-60 --half both` — and opens them together.
- Fetch the images before you delegate: a delegate never fetches, nor waits
  for an archive — it reports the images missing or too small, and you fetch them.
- Every delegate gets the full question (what counts as a find, which years,
  which names) and exactly what to write down — page numbers and headings
  only, the entries of one surname, one entry whole: it transcribes nothing
  else. It returns for each image: image and page, find, nothing or unclear
  (where on the image), what was illegible, the hand, certainty per name.
- A delegate's "unclear" on an image of the range: look at that place closer
  (`--crop`) before you record the range as searched in vain — else record
  it inconclusive, with the place in its note.
- Delegates never write to the research. You record their findings through
  strom; a negative result of a delegate is recorded as a search "by reader".
- Only entries that will get a citation need your own eyes.
- Send independent batches in ONE message so they run in parallel.
- Do not read a subagent's transcript or output file — its images would come
  into your context. Use only its final answer.

<!-- strom: generated above this line (strom agents sync); your own notes below are kept -->
